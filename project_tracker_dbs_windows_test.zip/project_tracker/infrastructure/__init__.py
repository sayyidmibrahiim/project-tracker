"""Infrastructure adapters."""
