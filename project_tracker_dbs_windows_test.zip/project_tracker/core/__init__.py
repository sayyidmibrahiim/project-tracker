"""Core domain layer."""
